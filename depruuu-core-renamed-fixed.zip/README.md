# DEPRUUU CORE Discord Bot v2

Render:
- Build: `npm install`
- Start: `node bot.js`

Environment:
- `DISCORD_TOKEN` = Bot Token (secret)
- `DISCORD_GUILD_ID` = `1552632205740613692`

Developer Portal:
- Server Members Intent: ON
- Presence Intent: ON
- Message Content Intent: not required

API:
- `/api/stats`
- `/api/members`
- `/api/members/:id`
- `/api/welcome`
